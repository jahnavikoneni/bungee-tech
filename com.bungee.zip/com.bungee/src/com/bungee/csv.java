package com.bungee;

public interface csv {
	
	void readCsv();
	
}
